# Learnova — Peer Learning & Academic Collaboration Platform

NSBM Green University — Web and Mobile Application Development (Batch 26.1)
Final Project — **Topic 2: StudyMate / Learnova**

Built with PHP (mysqli, procedural), MySQL, HTML/CSS/JS and Bootstrap 5.

## Features

**Admin**
- Login
- Manage users (view, block/activate, delete students)
- Approve / reject uploaded notes
- Approve / reject / delete study groups (new members can't join until approved)
- Manage subjects and categories
- Moderate discussions (hide/delete questions, answers, note comments, and group chat messages)

**Student**
- Register and login
- Upload lecture notes (goes to "pending" until admin approval)
- Browse / search / filter and download approved notes
- Comment and rate notes (1-5 stars)
- Ask and answer academic questions
- Create study groups (max 10 members, needs admin approval before others can join)
- Join active study groups, chat on a group message wall, see the member list

## Tech Stack
- Frontend: HTML5, CSS3, JavaScript, Bootstrap 5 (via CDN)
- Backend: PHP 8 (mysqli, prepared statements throughout)
- Database: MySQL / MariaDB

## Setup (XAMPP / WAMP / MAMP)

1. Copy the `learnova` folder into your server's web root:
   - XAMPP (Windows): `C:\xampp\htdocs\learnova`
   - MAMP (Mac): `/Applications/MAMP/htdocs/learnova`
2. Start Apache and MySQL from your control panel.
3. Open **phpMyAdmin** (`http://localhost/phpmyadmin`).
4. Import `database/learnova.sql` (this creates the `learnova` database, all tables, and seed data automatically - no need to create the database manually first).
5. Check `config/db.php` - the defaults (`localhost` / `root` / no password / `learnova`) match a stock XAMPP/WAMP install. Edit if your MySQL user/password differs.
6. Make sure `uploads/materials/` is writable (it is by default).
7. Visit `http://localhost/learnova/` in your browser.

## Demo Login

| Role  | Email                | Password  |
|-------|------------------------|-----------|
| Admin | admin@learnova.com     | admin123  |

Register a new account from the site to test the Student role.

## Notes on Design

- Light theme with a stained-glass forest hero image and an open-book logo/favicon.
- Login/register use a full-page background photo with a frosted glass card. The "Continue with Google" button is a **visual placeholder only** - it isn't wired up to real Google OAuth, which is outside the module's PHP/MySQL scope.
- The study group "chat" is a **message wall**, not real-time chat: messages are saved to the database and shown on page reload/refresh. This fits the PHP/MySQL CRUD requirement without needing WebSockets or a separate real-time server.
- "Notes" in the UI is the same underlying `materials` table/feature from the original brief - only the on-screen label changed.

## Folder Structure

```
learnova/
├── admin/                    Admin panel pages (incl. approve_groups.php)
├── student/                  Student panel pages (incl. study_groups.php, group_view.php)
├── includes/                 header_guest/footer_guest (landing page),
│                              sidebar_start/app_footer (dashboard layout), auth.php
├── config/db.php             Database connection settings
├── assets/css, assets/js     Styles and client-side scripts
├── assets/img/                Background photo + favicon
├── assets/video/               Optional: drop hero.mp4 here for a video hero background
├── uploads/materials/           Uploaded files land here
├── database/learnova.sql        Full schema + seed data
├── index.php, login.php, register.php, logout.php
```

## Notes for the Project Report
- Screenshots: log in as admin and as a student and capture each panel listed in the assignment brief (login, admin panel, student panel, CRUD operations, database).
- CRUD is implemented for: notes/materials, questions, answers, study groups, group membership, group chat messages, comments/ratings, subjects, categories, and users.
- All queries use prepared statements to prevent SQL injection; passwords are hashed with `password_hash()`/`password_verify()`.
