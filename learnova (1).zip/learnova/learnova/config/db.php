<?php
// =====================================================
// Learnova - Database Connection
// Update these credentials to match your local MySQL setup
// (defaults match a standard XAMPP/WAMP/MAMP install)
// =====================================================

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'learnova';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');
