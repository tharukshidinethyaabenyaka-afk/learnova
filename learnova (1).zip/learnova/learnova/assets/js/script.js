// =====================================================
// Learnova - Client-side helpers
// =====================================================

// Bootstrap-style client-side validation for any form with class "needs-validation"
(function () {
  const forms = document.querySelectorAll('.needs-validation');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();

// Confirm before any destructive action (delete buttons)
document.addEventListener('click', function (e) {
  const target = e.target.closest('.confirm-action');
  if (target) {
    const msg = target.getAttribute('data-confirm') || 'Are you sure?';
    if (!confirm(msg)) {
      e.preventDefault();
    }
  }
});

// Auto-scroll the study group chat wall to the latest message on load
(function () {
  const wall = document.querySelector('.chat-wall');
  const bottom = document.getElementById('chatBottom');
  if (wall && bottom) {
    wall.scrollTop = wall.scrollHeight;
  }
})();

// Simple interactive star rating input (used on material detail page)
function initStarRating(containerId, inputId) {
  const container = document.getElementById(containerId);
  const input = document.getElementById(inputId);
  if (!container || !input) return;

  const stars = container.querySelectorAll('.star');
  function paint(value) {
    stars.forEach((s) => {
      s.textContent = parseInt(s.dataset.value) <= value ? '★' : '☆';
    });
  }
  stars.forEach((star) => {
    star.addEventListener('click', () => {
      const value = parseInt(star.dataset.value);
      input.value = value;
      paint(value);
    });
  });
  paint(parseInt(input.value || 5));
}

// Live search filter for simple client-side lists (materials/questions search boxes)
function liveFilter(inputId, itemSelector) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('keyup', function () {
    const term = this.value.toLowerCase();
    document.querySelectorAll(itemSelector).forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(term) ? '' : 'none';
    });
  });
}
