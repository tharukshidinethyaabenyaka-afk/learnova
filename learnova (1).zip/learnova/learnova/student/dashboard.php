<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();

$myMaterials = $conn->prepare('SELECT COUNT(*) c FROM materials WHERE uploaded_by = ?');
$myMaterials->bind_param('i', $uid);
$myMaterials->execute();
$myMaterialsCount = $myMaterials->get_result()->fetch_assoc()['c'];

$myQuestions = $conn->prepare('SELECT COUNT(*) c FROM questions WHERE user_id = ?');
$myQuestions->bind_param('i', $uid);
$myQuestions->execute();
$myQuestionsCount = $myQuestions->get_result()->fetch_assoc()['c'];

$myGroups = $conn->prepare('SELECT COUNT(*) c FROM group_members WHERE user_id = ?');
$myGroups->bind_param('i', $uid);
$myGroups->execute();
$myGroupsCount = $myGroups->get_result()->fetch_assoc()['c'];

$totalApproved = $conn->query("SELECT COUNT(*) c FROM materials WHERE status='approved'")->fetch_assoc()['c'];

$recentMaterials = $conn->query("SELECT m.*, s.name subject_name FROM materials m
    JOIN subjects s ON s.id = m.subject_id
    WHERE m.status = 'approved' ORDER BY m.created_at DESC LIMIT 5");

$recentQuestions = $conn->query("SELECT q.*, u.name author FROM questions q
    JOIN users u ON u.id = q.user_id
    WHERE q.status = 'visible' ORDER BY q.created_at DESC LIMIT 5");

$BASE = '../';
$PAGE_TITLE = 'Dashboard';
$ACTIVE = 'dashboard';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-1">Welcome back, <?php echo e(explode(' ', currentUserName())[0]); ?></h3>
<p class="text-muted mb-4">Here's what's happening in your Learnova community.</p>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><small>My Uploads</small><h2><?php echo (int)$myMaterialsCount; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>My Questions</small><h2><?php echo (int)$myQuestionsCount; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>My Groups</small><h2><?php echo (int)$myGroupsCount; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>Total Notes</small><h2><?php echo (int)$totalApproved; ?></h2></div></div>
</div>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        Recent Notes
        <a href="materials.php" class="btn btn-sm btn-outline-primary">View all</a>
      </div>
      <div class="card-body">
        <?php if ($recentMaterials->num_rows === 0): ?>
          <p class="text-muted mb-0">No notes yet.</p>
        <?php endif; ?>
        <?php while ($m = $recentMaterials->fetch_assoc()): ?>
          <div class="d-flex justify-content-between border-bottom py-2" style="border-color: var(--sm-border);">
            <div>
              <strong><?php echo e($m['title']); ?></strong><br>
              <small class="text-muted"><?php echo e($m['subject_name']); ?></small>
            </div>
            <a href="material_view.php?id=<?php echo $m['id']; ?>" class="btn btn-sm btn-light">View</a>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        Recent Questions
        <a href="questions.php" class="btn btn-sm btn-outline-primary">View all</a>
      </div>
      <div class="card-body">
        <?php if ($recentQuestions->num_rows === 0): ?>
          <p class="text-muted mb-0">No questions yet.</p>
        <?php endif; ?>
        <?php while ($q = $recentQuestions->fetch_assoc()): ?>
          <div class="d-flex justify-content-between border-bottom py-2" style="border-color: var(--sm-border);">
            <div>
              <strong><?php echo e($q['title']); ?></strong><br>
              <small class="text-muted">by <?php echo e($q['author']); ?></small>
            </div>
            <a href="question_view.php?id=<?php echo (int)$q['id']; ?>" class="btn btn-sm btn-light">View</a>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
