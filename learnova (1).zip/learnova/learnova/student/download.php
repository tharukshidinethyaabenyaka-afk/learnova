<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM materials WHERE id = ? AND (status = 'approved' OR uploaded_by = ?)");
$uid = currentUserId();
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$material = $stmt->get_result()->fetch_assoc();

if (!$material) {
    $_SESSION['flash_error'] = 'File not found.';
    header('Location: materials.php');
    exit;
}

$filePath = '../' . $material['file_path'];
if (!file_exists($filePath)) {
    $_SESSION['flash_error'] = 'File is missing on the server.';
    header('Location: materials.php');
    exit;
}

// increment download counter
$upd = $conn->prepare('UPDATE materials SET downloads = downloads + 1 WHERE id = ?');
$upd->bind_param('i', $id);
$upd->execute();

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
