<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT m.*, s.name subject_name, c.name category_name, u.name uploader
    FROM materials m
    JOIN subjects s ON s.id = m.subject_id
    JOIN categories c ON c.id = m.category_id
    JOIN users u ON u.id = m.uploaded_by
    WHERE m.id = ? AND (m.status = 'approved' OR m.uploaded_by = ?)");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$material = $stmt->get_result()->fetch_assoc();

if (!$material) {
    $_SESSION['flash_error'] = 'Note not found.';
    header('Location: materials.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = trim($_POST['comment']);
    $rating = max(1, min(5, (int)($_POST['rating'] ?? 5)));
    if ($comment !== '') {
        $stmt = $conn->prepare('INSERT INTO material_comments (material_id, user_id, comment, rating) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('iisi', $id, $uid, $comment, $rating);
        $stmt->execute();
    }
    header('Location: material_view.php?id=' . $id);
    exit;
}

$comments = $conn->prepare('SELECT mc.*, u.name author FROM material_comments mc
    JOIN users u ON u.id = mc.user_id WHERE mc.material_id = ? ORDER BY mc.created_at DESC');
$comments->bind_param('i', $id);
$comments->execute();
$comments = $comments->get_result();

$BASE = '../';
$PAGE_TITLE = $material['title'];
$ACTIVE = 'materials';
require '../includes/sidebar_start.php';
?>

<div class="card mb-4">
  <div class="card-body">
    <div class="d-flex justify-content-between flex-wrap">
      <h4><?php echo e($material['title']); ?></h4>
      <span class="badge badge-<?php echo $material['status']; ?> align-self-start"><?php echo ucfirst($material['status']); ?></span>
    </div>
    <p class="text-muted mb-1"><?php echo e($material['subject_name']); ?> &middot; <?php echo e($material['category_name']); ?></p>
    <p><?php echo nl2br(e($material['description'])); ?></p>
    <p class="small text-muted">Uploaded by <?php echo e($material['uploader']); ?> on <?php echo date('d M Y', strtotime($material['created_at'])); ?> &middot; <?php echo (int)$material['downloads']; ?> downloads</p>
    <a href="download.php?id=<?php echo $material['id']; ?>" class="btn btn-primary">⬇ Download File</a>
    <a href="materials.php" class="btn btn-outline-secondary">Back to Notes</a>
  </div>
</div>

<div class="card">
  <div class="card-header">Comments &amp; Ratings (<?php echo $comments->num_rows; ?>)</div>
  <div class="card-body">
    <form method="POST" class="mb-4">
      <div class="mb-2">
        <label class="form-label">Your rating</label>
        <div id="starBox" class="star-input">
          <?php for ($i = 1; $i <= 5; $i++): ?>
            <span class="star" data-value="<?php echo $i; ?>">☆</span>
          <?php endfor; ?>
        </div>
        <input type="hidden" name="rating" id="ratingInput" value="5">
      </div>
      <div class="mb-2">
        <textarea name="comment" class="form-control" rows="2" placeholder="Share your thoughts on this resource..." required></textarea>
      </div>
      <button type="submit" class="btn btn-outline-primary">Post Comment</button>
    </form>

    <?php if ($comments->num_rows === 0): ?>
      <p class="text-muted">No comments yet. Be the first to review this note.</p>
    <?php endif; ?>
    <?php while ($c = $comments->fetch_assoc()): ?>
      <div class="border-bottom py-2" style="border-color: var(--sm-border);">
        <strong><?php echo e($c['author']); ?></strong>
        <span class="rating-stars"><?php echo str_repeat('★', $c['rating']) . str_repeat('☆', 5 - $c['rating']); ?></span>
        <br>
        <span><?php echo e($c['comment']); ?></span><br>
        <small class="text-muted"><?php echo date('d M Y, H:i', strtotime($c['created_at'])); ?></small>
      </div>
    <?php endwhile; ?>
  </div>
</div>

<script>initStarRating('starBox', 'ratingInput');</script>

<?php require '../includes/app_footer.php'; ?>
