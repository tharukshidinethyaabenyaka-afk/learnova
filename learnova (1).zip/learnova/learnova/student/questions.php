<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ask'])) {
    $title = trim($_POST['title'] ?? '');
    $body = trim($_POST['body'] ?? '');
    $subjectId = (int)($_POST['subject_id'] ?? 0);

    if ($title === '' || $body === '' || $subjectId <= 0) {
        $errors[] = 'Please fill in title, subject and details of your question.';
    } else {
        $stmt = $conn->prepare('INSERT INTO questions (user_id, subject_id, title, body) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('iiss', $uid, $subjectId, $title, $body);
        $stmt->execute();
        $_SESSION['flash_success'] = 'Question posted!';
        header('Location: questions.php');
        exit;
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare('DELETE FROM questions WHERE id = ? AND user_id = ?');
    $stmt->bind_param('ii', $id, $uid);
    $stmt->execute();
    header('Location: questions.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$sql = "SELECT q.*, u.name author, s.name subject_name,
        (SELECT COUNT(*) FROM answers a WHERE a.question_id = q.id AND a.status='visible') answer_count
        FROM questions q JOIN users u ON u.id = q.user_id JOIN subjects s ON s.id = q.subject_id
        WHERE q.status = 'visible'";
$params = [];
$types = '';
if ($search !== '') {
    $sql .= ' AND (q.title LIKE ? OR q.body LIKE ?)';
    $like = "%$search%";
    $params = [$like, $like];
    $types = 'ss';
}
$sql .= ' ORDER BY q.created_at DESC';
$stmt = $conn->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$questions = $stmt->get_result();

$subjects = $conn->query('SELECT * FROM subjects ORDER BY name');

$BASE = '../';
$PAGE_TITLE = 'Q&A';
$ACTIVE = 'questions';
require '../includes/sidebar_start.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <h3 class="mb-0">Q&amp;A</h3>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#askModal">+ Ask a Question</button>
</div>

<?php foreach ($errors as $err): ?>
  <div class="alert alert-danger"><?php echo e($err); ?></div>
<?php endforeach; ?>

<form method="GET" class="mb-4 row g-2">
  <div class="col-md-6">
    <input type="text" name="q" class="form-control" placeholder="Search questions..." value="<?php echo e($search); ?>">
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-primary w-100">Search</button>
  </div>
</form>

<?php if ($questions->num_rows === 0): ?>
  <p class="text-muted">No questions yet. Be the first to ask!</p>
<?php endif; ?>

<?php while ($q = $questions->fetch_assoc()): ?>
  <div class="card mb-2">
    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <a href="question_view.php?id=<?php echo $q['id']; ?>" class="fw-bold text-decoration-none" style="color:var(--sm-text);"><?php echo e($q['title']); ?></a>
        <p class="small text-muted mb-0"><?php echo e($q['subject_name']); ?> &middot; by <?php echo e($q['author']); ?> &middot; <?php echo date('d M Y', strtotime($q['created_at'])); ?> &middot; <?php echo $q['answer_count']; ?> answers</p>
      </div>
      <div class="d-flex gap-2">
        <a href="question_view.php?id=<?php echo $q['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
        <?php if ($q['user_id'] == $uid): ?>
          <a href="questions.php?delete=<?php echo $q['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this question?">Delete</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endwhile; ?>

<div class="modal fade" id="askModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5 class="modal-title">Ask a Question</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Subject</label>
            <select name="subject_id" class="form-select" required>
              <option value="">Select subject</option>
              <?php $subjects->data_seek(0); while ($s = $subjects->fetch_assoc()): ?>
                <option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Details</label>
            <textarea name="body" class="form-control" rows="4" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="ask" value="1" class="btn btn-primary">Post Question</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
