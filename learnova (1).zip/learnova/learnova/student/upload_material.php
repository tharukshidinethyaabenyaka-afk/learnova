<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$errors = [];

$subjects = $conn->query('SELECT * FROM subjects ORDER BY name');
$categories = $conn->query('SELECT * FROM categories ORDER BY name');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $subjectId = (int)($_POST['subject_id'] ?? 0);
    $categoryId = (int)($_POST['category_id'] ?? 0);

    if ($title === '' || $subjectId <= 0 || $categoryId <= 0) {
        $errors[] = 'Title, subject and category are required.';
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Please choose a file to upload.';
    } else {
        $allowedExt = ['pdf','doc','docx','ppt','pptx','txt','zip','png','jpg','jpeg'];
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt)) {
            $errors[] = 'File type not allowed. Allowed: ' . implode(', ', $allowedExt);
        }
        if ($_FILES['file']['size'] > 10 * 1024 * 1024) {
            $errors[] = 'File is too large (max 10MB).';
        }
    }

    if (empty($errors)) {
        $uploadDir = '../uploads/materials/';
        if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }

        $safeName = uniqid('note_') . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $_FILES['file']['name']);
        $destination = $uploadDir . $safeName;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $destination)) {
            $storedPath = 'uploads/materials/' . $safeName;
            $stmt = $conn->prepare('INSERT INTO materials (title, description, subject_id, category_id, file_path, uploaded_by, status) VALUES (?, ?, ?, ?, ?, ?, "pending")');
            $stmt->bind_param('ssiisi', $title, $description, $subjectId, $categoryId, $storedPath, $uid);
            $stmt->execute();

            $_SESSION['flash_success'] = 'Note uploaded! It will be visible once approved by an admin.';
            header('Location: materials.php?mine=1');
            exit;
        } else {
            $errors[] = 'Failed to save the uploaded file.';
        }
    }
}

$BASE = '../';
$PAGE_TITLE = 'Upload Note';
$ACTIVE = 'materials';
require '../includes/sidebar_start.php';
?>

<div class="card" style="max-width:640px;margin:0 auto;">
  <div class="card-header">Upload Lecture Notes / Study Material</div>
  <div class="card-body">
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger"><?php echo e($err); ?></div>
    <?php endforeach; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Title</label>
        <input type="text" name="title" class="form-control" required value="<?php echo e($_POST['title'] ?? ''); ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="3"><?php echo e($_POST['description'] ?? ''); ?></textarea>
      </div>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Subject</label>
          <select name="subject_id" class="form-select" required>
            <option value="">Select subject</option>
            <?php while ($s = $subjects->fetch_assoc()): ?>
              <option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-select" required>
            <option value="">Select category</option>
            <?php while ($c = $categories->fetch_assoc()): ?>
              <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">File (PDF, DOC, PPT, ZIP, image - max 10MB)</label>
        <input type="file" name="file" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Upload</button>
    </form>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
