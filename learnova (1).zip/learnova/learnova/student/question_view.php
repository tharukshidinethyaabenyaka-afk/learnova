<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT q.*, u.name author, s.name subject_name FROM questions q
    JOIN users u ON u.id = q.user_id JOIN subjects s ON s.id = q.subject_id
    WHERE q.id = ? AND q.status = 'visible'");
$stmt->bind_param('i', $id);
$stmt->execute();
$question = $stmt->get_result()->fetch_assoc();

if (!$question) {
    $_SESSION['flash_error'] = 'Question not found.';
    header('Location: questions.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['answer'])) {
    $body = trim($_POST['answer']);
    if ($body !== '') {
        $stmt = $conn->prepare('INSERT INTO answers (question_id, user_id, body) VALUES (?, ?, ?)');
        $stmt->bind_param('iis', $id, $uid, $body);
        $stmt->execute();
    }
    header('Location: question_view.php?id=' . $id);
    exit;
}

$answers = $conn->prepare("SELECT a.*, u.name author FROM answers a
    JOIN users u ON u.id = a.user_id WHERE a.question_id = ? AND a.status = 'visible' ORDER BY a.created_at ASC");
$answers->bind_param('i', $id);
$answers->execute();
$answers = $answers->get_result();

$BASE = '../';
$PAGE_TITLE = $question['title'];
$ACTIVE = 'questions';
require '../includes/sidebar_start.php';
?>

<div class="card mb-4">
  <div class="card-body">
    <h4><?php echo e($question['title']); ?></h4>
    <p class="text-muted small mb-2"><?php echo e($question['subject_name']); ?> &middot; asked by <?php echo e($question['author']); ?> on <?php echo date('d M Y', strtotime($question['created_at'])); ?></p>
    <p><?php echo nl2br(e($question['body'])); ?></p>
    <a href="questions.php" class="btn btn-outline-secondary btn-sm">Back to Q&amp;A</a>
  </div>
</div>

<h5>Answers (<?php echo $answers->num_rows; ?>)</h5>
<?php if ($answers->num_rows === 0): ?>
  <p class="text-muted">No answers yet. Be the first to help!</p>
<?php endif; ?>
<?php while ($a = $answers->fetch_assoc()): ?>
  <div class="card mb-2">
    <div class="card-body">
      <p class="mb-1"><?php echo nl2br(e($a['body'])); ?></p>
      <small class="text-muted">— <?php echo e($a['author']); ?>, <?php echo date('d M Y, H:i', strtotime($a['created_at'])); ?></small>
    </div>
  </div>
<?php endwhile; ?>

<div class="card mt-4">
  <div class="card-header">Post an Answer</div>
  <div class="card-body">
    <form method="POST">
      <textarea name="answer" class="form-control mb-2" rows="3" required placeholder="Write your answer..."></textarea>
      <button type="submit" class="btn btn-primary">Submit Answer</button>
    </form>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
