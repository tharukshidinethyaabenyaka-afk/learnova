<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare('DELETE FROM materials WHERE id = ? AND uploaded_by = ?');
    $stmt->bind_param('ii', $id, $uid);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Note deleted.';
    header('Location: materials.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$subjectFilter = (int)($_GET['subject'] ?? 0);
$mine = isset($_GET['mine']);

$sql = "SELECT m.*, s.name subject_name, c.name category_name, u.name uploader,
        (SELECT ROUND(AVG(rating),1) FROM material_comments WHERE material_id = m.id) avg_rating,
        (SELECT COUNT(*) FROM material_comments WHERE material_id = m.id) comment_count
        FROM materials m
        JOIN subjects s ON s.id = m.subject_id
        JOIN categories c ON c.id = m.category_id
        JOIN users u ON u.id = m.uploaded_by
        WHERE 1=1";
$params = [];
$types = '';

if ($mine) {
    $sql .= ' AND m.uploaded_by = ?';
    $params[] = $uid;
    $types .= 'i';
} else {
    $sql .= " AND m.status = 'approved'";
}

if ($search !== '') {
    $sql .= ' AND (m.title LIKE ? OR m.description LIKE ?)';
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $types .= 'ss';
}

if ($subjectFilter > 0) {
    $sql .= ' AND m.subject_id = ?';
    $params[] = $subjectFilter;
    $types .= 'i';
}

$sql .= ' ORDER BY m.created_at DESC';

$stmt = $conn->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$materials = $stmt->get_result();

$subjects = $conn->query('SELECT * FROM subjects ORDER BY name');

$BASE = '../';
$PAGE_TITLE = 'Notes';
$ACTIVE = 'materials';
require '../includes/sidebar_start.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <h3 class="mb-0">Notes</h3>
  <a href="upload_material.php" class="btn btn-primary">+ Upload Note</a>
</div>

<form method="GET" class="row g-2 mb-4">
  <div class="col-md-5">
    <input type="text" name="q" class="form-control" placeholder="Search by title or description..." value="<?php echo e($search); ?>">
  </div>
  <div class="col-md-3">
    <select name="subject" class="form-select">
      <option value="0">All Subjects</option>
      <?php while ($s = $subjects->fetch_assoc()): ?>
        <option value="<?php echo $s['id']; ?>" <?php echo $subjectFilter == $s['id'] ? 'selected' : ''; ?>><?php echo e($s['name']); ?></option>
      <?php endwhile; ?>
    </select>
  </div>
  <div class="col-md-2 form-check d-flex align-items-center">
    <input type="checkbox" class="form-check-input me-2" id="mine" name="mine" value="1" <?php echo $mine ? 'checked' : ''; ?> onchange="this.form.submit()">
    <label class="form-check-label" for="mine">My Uploads</label>
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-primary w-100">Filter</button>
  </div>
</form>

<div class="row g-3">
  <?php if ($materials->num_rows === 0): ?>
    <p class="text-muted">No notes found.</p>
  <?php endif; ?>
  <?php while ($m = $materials->fetch_assoc()): ?>
    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between">
            <h6 class="fw-bold"><?php echo e($m['title']); ?></h6>
            <?php if ($mine): ?>
              <span class="badge badge-<?php echo $m['status']; ?>"><?php echo ucfirst($m['status']); ?></span>
            <?php endif; ?>
          </div>
          <p class="text-muted small mb-1"><?php echo e($m['subject_name']); ?> &middot; <?php echo e($m['category_name']); ?></p>
          <p class="small mb-2"><?php echo e(mb_strimwidth($m['description'], 0, 90, '...')); ?></p>
          <p class="small text-muted mb-2">By <?php echo e($m['uploader']); ?> &middot; <?php echo (int)$m['downloads']; ?> downloads
          <?php if ($m['avg_rating']): ?>
            &middot; <span class="rating-stars">★</span> <?php echo $m['avg_rating']; ?> (<?php echo $m['comment_count']; ?>)
          <?php endif; ?>
          </p>
        </div>
        <div class="card-footer d-flex gap-2">
          <a href="material_view.php?id=<?php echo $m['id']; ?>" class="btn btn-sm btn-primary flex-fill">View / Download</a>
          <?php if ($mine): ?>
            <a href="materials.php?delete=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this note?">Delete</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endwhile; ?>
</div>

<?php require '../includes/app_footer.php'; ?>
