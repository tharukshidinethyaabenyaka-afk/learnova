<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare('SELECT g.*, s.name subject_name, u.name creator FROM study_groups g
    JOIN subjects s ON s.id = g.subject_id JOIN users u ON u.id = g.created_by WHERE g.id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$group = $stmt->get_result()->fetch_assoc();

if (!$group) {
    $_SESSION['flash_error'] = 'Group not found.';
    header('Location: study_groups.php');
    exit;
}

// Membership required to view this group at all
$check = $conn->prepare('SELECT id FROM group_members WHERE group_id = ? AND user_id = ?');
$check->bind_param('ii', $id, $uid);
$check->execute();
if ($check->get_result()->num_rows === 0) {
    $_SESSION['flash_error'] = 'Join the group first to view its details.';
    header('Location: study_groups.php');
    exit;
}

// Post a new message to the group wall
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $msg = trim($_POST['message']);
    if ($msg !== '') {
        $stmt = $conn->prepare('INSERT INTO group_messages (group_id, user_id, message) VALUES (?, ?, ?)');
        $stmt->bind_param('iis', $id, $uid, $msg);
        $stmt->execute();
    }
    header('Location: group_view.php?id=' . $id . '#chatBottom');
    exit;
}

$memberCount = $conn->prepare('SELECT COUNT(*) c FROM group_members WHERE group_id = ?');
$memberCount->bind_param('i', $id);
$memberCount->execute();
$memberCount = $memberCount->get_result()->fetch_assoc()['c'];

$members = $conn->prepare('SELECT u.id, u.name, gm.joined_at FROM group_members gm
    JOIN users u ON u.id = gm.user_id WHERE gm.group_id = ? ORDER BY gm.joined_at ASC');
$members->bind_param('i', $id);
$members->execute();
$members = $members->get_result();

$messages = $conn->prepare('SELECT gm.*, u.name author FROM group_messages gm
    JOIN users u ON u.id = gm.user_id WHERE gm.group_id = ? ORDER BY gm.created_at ASC');
$messages->bind_param('i', $id);
$messages->execute();
$messages = $messages->get_result();

$BASE = '../';
$PAGE_TITLE = $group['name'];
$ACTIVE = 'groups';
require '../includes/sidebar_start.php';
?>

<a href="study_groups.php" class="btn btn-outline-secondary btn-sm mb-3">&larr; Back to Study Group</a>

<div class="card">
  <div class="chat-header border-bottom" style="border-color: var(--sm-border);">
    <div class="group-avatar"><?php echo e(userInitials($group['name'])); ?></div>
    <div class="flex-grow-1">
      <div class="fw-bold" style="color:var(--sm-text);">
        <?php echo e($group['name']); ?>
        <?php if ($group['status'] !== 'active'): ?>
          <span class="badge badge-group-pending ms-1">Pending Approval</span>
        <?php endif; ?>
      </div>
      <div class="text-muted small"><?php echo e($group['subject_name']); ?> &middot; <?php echo (int)$memberCount; ?>/<?php echo (int)$group['max_members']; ?> members</div>
    </div>
  </div>

  <div class="chat-wall">
    <?php if ($messages->num_rows === 0): ?>
      <p class="text-muted text-center small mb-0">No messages yet. Say hello to the group!</p>
    <?php endif; ?>
    <?php while ($m = $messages->fetch_assoc()): ?>
      <?php $mine = ((int)$m['user_id'] === (int)$uid); ?>
      <div class="chat-msg <?php echo $mine ? 'msg-mine' : ''; ?>">
        <div class="msg-avatar"><?php echo e(userInitials($m['author'])); ?></div>
        <div>
          <div class="msg-bubble">
            <?php if (!$mine): ?><div class="msg-author"><?php echo e($m['author']); ?></div><?php endif; ?>
            <?php echo nl2br(e($m['message'])); ?>
          </div>
          <span class="msg-time"><?php echo date('g:i A', strtotime($m['created_at'])); ?></span>
        </div>
      </div>
    <?php endwhile; ?>
    <div id="chatBottom"></div>
  </div>

  <form method="POST" class="chat-input-bar">
    <input type="text" name="message" class="form-control" placeholder="Write a message to the group..." required autocomplete="off">
    <button type="submit" class="btn btn-primary">Send</button>
  </form>
</div>

<div class="card mt-4">
  <div class="card-header">Members (<?php echo (int)$memberCount; ?>/<?php echo (int)$group['max_members']; ?>)</div>
  <ul class="list-group list-group-flush">
    <?php while ($m = $members->fetch_assoc()): ?>
      <li class="list-group-item d-flex justify-content-between align-items-center">
        <span class="d-flex align-items-center gap-2">
          <span class="member-avatar-sm" style="margin-left:0;"><?php echo e(userInitials($m['name'])); ?></span>
          <?php echo e($m['name']); ?>
          <?php if ((int)$m['id'] === (int)$group['created_by']): ?>
            <span class="badge" style="background:var(--sm-surface-hover); color:var(--sm-text); border:1px solid var(--sm-border);">Creator</span>
          <?php endif; ?>
        </span>
        <small class="text-muted">joined <?php echo date('d M Y', strtotime($m['joined_at'])); ?></small>
      </li>
    <?php endwhile; ?>
  </ul>
</div>

<?php require '../includes/app_footer.php'; ?>
