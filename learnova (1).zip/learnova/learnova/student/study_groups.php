<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudent();

$uid = currentUserId();
$errors = [];

// Create a new group (goes in as "pending" until an admin approves it)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $subjectId = (int)($_POST['subject_id'] ?? 0);

    if ($name === '' || $subjectId <= 0) {
        $errors[] = 'Please provide a group name and subject.';
    } else {
        $conn->begin_transaction();
        $stmt = $conn->prepare('INSERT INTO study_groups (name, description, subject_id, created_by, status, max_members) VALUES (?, ?, ?, ?, "pending", 10)');
        $stmt->bind_param('ssii', $name, $description, $subjectId, $uid);
        $stmt->execute();
        $groupId = $conn->insert_id;

        // creator is added as a member right away, even while pending approval
        $stmt2 = $conn->prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)');
        $stmt2->bind_param('ii', $groupId, $uid);
        $stmt2->execute();
        $conn->commit();

        $_SESSION['flash_success'] = 'Study group created! It needs admin approval before other students can join.';
        header('Location: study_groups.php');
        exit;
    }
}

// Join a group (only allowed if active and under the member cap)
if (isset($_GET['join'])) {
    $gid = (int)$_GET['join'];
    $stmt = $conn->prepare("SELECT g.max_members, g.status,
        (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) member_count
        FROM study_groups g WHERE g.id = ?");
    $stmt->bind_param('i', $gid);
    $stmt->execute();
    $group = $stmt->get_result()->fetch_assoc();

    if (!$group || $group['status'] !== 'active') {
        $_SESSION['flash_error'] = 'This group is not open for joining yet.';
    } elseif ($group['member_count'] >= $group['max_members']) {
        $_SESSION['flash_error'] = 'This group is already full (max ' . $group['max_members'] . ' members).';
    } else {
        $stmt = $conn->prepare('INSERT IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)');
        $stmt->bind_param('ii', $gid, $uid);
        $stmt->execute();
        $_SESSION['flash_success'] = 'You joined the group!';
    }
    header('Location: study_groups.php');
    exit;
}

// Leave a group
if (isset($_GET['leave'])) {
    $gid = (int)$_GET['leave'];
    $stmt = $conn->prepare('DELETE FROM group_members WHERE group_id = ? AND user_id = ?');
    $stmt->bind_param('ii', $gid, $uid);
    $stmt->execute();
    header('Location: study_groups.php');
    exit;
}

$groups = $conn->prepare("SELECT g.*, s.name subject_name, u.name creator,
    (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) member_count,
    (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id AND gm.user_id = ?) joined
    FROM study_groups g
    JOIN subjects s ON s.id = g.subject_id
    JOIN users u ON u.id = g.created_by
    WHERE g.status != 'rejected'
    ORDER BY g.created_at DESC");
$groups->bind_param('i', $uid);
$groups->execute();
$groups = $groups->get_result();

$subjects = $conn->query('SELECT * FROM subjects ORDER BY name');

$BASE = '../';
$PAGE_TITLE = 'Study Group';
$ACTIVE = 'groups';
require '../includes/sidebar_start.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h3 class="mb-0">Study Group</h3>
    <p class="text-muted small mb-0">Groups need admin approval before becoming active. Max 10 members per group.</p>
  </div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal">+ Create Group</button>
</div>

<?php foreach ($errors as $err): ?>
  <div class="alert alert-danger"><?php echo e($err); ?></div>
<?php endforeach; ?>

<div class="card">
  <?php if ($groups->num_rows === 0): ?>
    <div class="card-body"><p class="text-muted mb-0">No study groups yet. Create the first one!</p></div>
  <?php endif; ?>
  <?php $i = 0; $total = $groups->num_rows; while ($g = $groups->fetch_assoc()): $i++; ?>
    <div class="group-card <?php echo $i < $total ? 'border-bottom' : ''; ?>" style="border-color: var(--sm-border);">
      <div class="group-avatar"><?php echo e(userInitials($g['name'])); ?></div>
      <div class="group-meta">
        <div class="group-name"><?php echo e($g['name']); ?></div>
        <div class="group-sub"><?php echo e($g['subject_name']); ?> &middot; created by <?php echo e($g['creator']); ?></div>
      </div>
      <div class="text-end me-2">
        <div class="group-count"><?php echo (int)$g['member_count']; ?>/<?php echo (int)$g['max_members']; ?> members</div>
        <?php if ($g['status'] === 'active'): ?>
          <span class="badge badge-group-active">Active</span>
        <?php else: ?>
          <span class="badge badge-group-pending">Pending Approval</span>
        <?php endif; ?>
      </div>
      <div class="d-flex gap-2">
        <?php if ($g['joined']): ?>
          <a href="group_view.php?id=<?php echo $g['id']; ?>" class="btn btn-sm btn-primary">Open</a>
          <a href="study_groups.php?leave=<?php echo $g['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Leave this group?">Leave</a>
        <?php elseif ($g['status'] === 'active' && $g['member_count'] < $g['max_members']): ?>
          <a href="study_groups.php?join=<?php echo $g['id']; ?>" class="btn btn-sm btn-outline-primary">Join</a>
        <?php elseif ($g['status'] === 'active'): ?>
          <span class="badge bg-danger align-self-center">Full</span>
        <?php endif; ?>
      </div>
    </div>
  <?php endwhile; ?>
</div>

<div class="modal fade" id="createModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5 class="modal-title">Create a Study Group</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Group Name</label>
            <input type="text" name="name" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Subject</label>
            <select name="subject_id" class="form-select" required>
              <option value="">Select subject</option>
              <?php $subjects->data_seek(0); while ($s = $subjects->fetch_assoc()): ?>
                <option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="3"></textarea>
          </div>
          <div class="alert alert-success mb-0">Groups are capped at <strong>10 members</strong> and need admin approval before other students can join.</div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="create" value="1" class="btn btn-primary">Create Group</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
