<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $stmt = $conn->prepare("UPDATE users SET status = IF(status='active','blocked','active') WHERE id = ? AND role = 'student'");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: manage_users.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'student'");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'User deleted.';
    header('Location: manage_users.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM users WHERE role = 'student'";
$params = [];
$types = '';
if ($search !== '') {
    $sql .= ' AND (name LIKE ? OR email LIKE ?)';
    $like = "%$search%";
    $params = [$like, $like];
    $types = 'ss';
}
$sql .= ' ORDER BY created_at DESC';
$stmt = $conn->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$users = $stmt->get_result();

$BASE = '../';
$PAGE_TITLE = 'Manage Users';
$ACTIVE = 'users';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Manage Students</h3>

<form method="GET" class="row g-2 mb-4">
  <div class="col-md-4">
    <input type="text" name="q" class="form-control" placeholder="Search by name or email..." value="<?php echo e($search); ?>">
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-primary w-100">Search</button>
  </div>
</form>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead class="table-light">
        <tr><th>Name</th><th>Email</th><th>Contact</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php while ($u = $users->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($u['name']); ?></td>
            <td><?php echo e($u['email']); ?></td>
            <td><?php echo e($u['contact']); ?></td>
            <td><span class="badge bg-<?php echo $u['status'] === 'active' ? 'success' : 'danger'; ?>"><?php echo ucfirst($u['status']); ?></span></td>
            <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
            <td>
              <a href="manage_users.php?toggle=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-warning confirm-action" data-confirm="Change this user's status?">
                <?php echo $u['status'] === 'active' ? 'Block' : 'Activate'; ?>
              </a>
              <a href="manage_users.php?delete=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this user permanently?">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
        <?php if ($users->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-3">No students found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
