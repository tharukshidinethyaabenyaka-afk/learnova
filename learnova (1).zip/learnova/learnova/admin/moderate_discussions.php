<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if (isset($_GET['hide_q'])) {
    $id = (int)$_GET['hide_q'];
    $conn->query("UPDATE questions SET status = IF(status='visible','hidden','visible') WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}
if (isset($_GET['delete_q'])) {
    $id = (int)$_GET['delete_q'];
    $conn->query("DELETE FROM questions WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}
if (isset($_GET['hide_a'])) {
    $id = (int)$_GET['hide_a'];
    $conn->query("UPDATE answers SET status = IF(status='visible','hidden','visible') WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}
if (isset($_GET['delete_a'])) {
    $id = (int)$_GET['delete_a'];
    $conn->query("DELETE FROM answers WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}
if (isset($_GET['delete_c'])) {
    $id = (int)$_GET['delete_c'];
    $conn->query("DELETE FROM material_comments WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}
if (isset($_GET['delete_m'])) {
    $id = (int)$_GET['delete_m'];
    $conn->query("DELETE FROM group_messages WHERE id = $id");
    header('Location: moderate_discussions.php');
    exit;
}

$questions = $conn->query("SELECT q.*, u.name author FROM questions q JOIN users u ON u.id = q.user_id ORDER BY q.created_at DESC");
$answers = $conn->query("SELECT a.*, u.name author, q.title q_title FROM answers a JOIN users u ON u.id = a.user_id JOIN questions q ON q.id = a.question_id ORDER BY a.created_at DESC");
$comments = $conn->query("SELECT mc.*, u.name author, m.title m_title FROM material_comments mc JOIN users u ON u.id = mc.user_id JOIN materials m ON m.id = mc.material_id ORDER BY mc.created_at DESC");
$groupMessages = $conn->query("SELECT gm.*, u.name author, g.name group_name FROM group_messages gm JOIN users u ON u.id = gm.user_id JOIN study_groups g ON g.id = gm.group_id ORDER BY gm.created_at DESC LIMIT 100");

$BASE = '../';
$PAGE_TITLE = 'Moderation';
$ACTIVE = 'moderation';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Moderate Discussions</h3>

<ul class="nav nav-tabs mb-3">
  <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#tab-q">Questions</a></li>
  <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-a">Answers</a></li>
  <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-c">Note Comments</a></li>
  <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-m">Group Messages</a></li>
</ul>

<div class="tab-content">
  <div class="tab-pane fade show active" id="tab-q">
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light"><tr><th>Title</th><th>Author</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <?php while ($q = $questions->fetch_assoc()): ?>
              <tr>
                <td><?php echo e($q['title']); ?></td>
                <td><?php echo e($q['author']); ?></td>
                <td><span class="badge bg-<?php echo $q['status'] === 'visible' ? 'success' : 'danger'; ?>"><?php echo ucfirst($q['status']); ?></span></td>
                <td>
                  <a href="moderate_discussions.php?hide_q=<?php echo $q['id']; ?>" class="btn btn-sm btn-outline-warning"><?php echo $q['status'] === 'visible' ? 'Hide' : 'Unhide'; ?></a>
                  <a href="moderate_discussions.php?delete_q=<?php echo $q['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this question and its answers?">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="tab-pane fade" id="tab-a">
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light"><tr><th>Answer</th><th>Question</th><th>Author</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <?php while ($a = $answers->fetch_assoc()): ?>
              <tr>
                <td><?php echo e(mb_strimwidth($a['body'], 0, 60, '...')); ?></td>
                <td><?php echo e($a['q_title']); ?></td>
                <td><?php echo e($a['author']); ?></td>
                <td><span class="badge bg-<?php echo $a['status'] === 'visible' ? 'success' : 'danger'; ?>"><?php echo ucfirst($a['status']); ?></span></td>
                <td>
                  <a href="moderate_discussions.php?hide_a=<?php echo $a['id']; ?>" class="btn btn-sm btn-outline-warning"><?php echo $a['status'] === 'visible' ? 'Hide' : 'Unhide'; ?></a>
                  <a href="moderate_discussions.php?delete_a=<?php echo $a['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this answer?">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="tab-pane fade" id="tab-c">
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light"><tr><th>Comment</th><th>Note</th><th>Author</th><th>Rating</th><th>Actions</th></tr></thead>
          <tbody>
            <?php while ($c = $comments->fetch_assoc()): ?>
              <tr>
                <td><?php echo e(mb_strimwidth($c['comment'], 0, 60, '...')); ?></td>
                <td><?php echo e($c['m_title']); ?></td>
                <td><?php echo e($c['author']); ?></td>
                <td><?php echo str_repeat('★', $c['rating']); ?></td>
                <td>
                  <a href="moderate_discussions.php?delete_c=<?php echo $c['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this comment?">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="tab-pane fade" id="tab-m">
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light"><tr><th>Message</th><th>Group</th><th>Author</th><th>Actions</th></tr></thead>
          <tbody>
            <?php while ($m = $groupMessages->fetch_assoc()): ?>
              <tr>
                <td><?php echo e(mb_strimwidth($m['message'], 0, 60, '...')); ?></td>
                <td><?php echo e($m['group_name']); ?></td>
                <td><?php echo e($m['author']); ?></td>
                <td>
                  <a href="moderate_discussions.php?delete_m=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this message?">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
