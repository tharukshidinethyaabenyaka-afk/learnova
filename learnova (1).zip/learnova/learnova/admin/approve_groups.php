<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $stmt = $conn->prepare("UPDATE study_groups SET status = 'active' WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Study group approved.';
    header('Location: approve_groups.php');
    exit;
}

if (isset($_GET['reject'])) {
    $id = (int)$_GET['reject'];
    $stmt = $conn->prepare("UPDATE study_groups SET status = 'rejected' WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Study group rejected.';
    header('Location: approve_groups.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare('DELETE FROM study_groups WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Study group deleted.';
    header('Location: approve_groups.php');
    exit;
}

$statusFilter = $_GET['status'] ?? 'pending';
$allowed = ['pending', 'active', 'rejected', 'all'];
if (!in_array($statusFilter, $allowed)) { $statusFilter = 'pending'; }

$sql = "SELECT g.*, s.name subject_name, u.name creator,
        (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) member_count
        FROM study_groups g
        JOIN subjects s ON s.id = g.subject_id
        JOIN users u ON u.id = g.created_by";
if ($statusFilter !== 'all') {
    $sql .= " WHERE g.status = '" . $conn->real_escape_string($statusFilter) . "'";
}
$sql .= ' ORDER BY g.created_at DESC';
$groups = $conn->query($sql);

$BASE = '../';
$PAGE_TITLE = 'Study Groups';
$ACTIVE = 'groups';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Manage Study Groups</h3>

<ul class="nav nav-pills mb-4">
  <?php foreach (['pending' => 'Pending', 'active' => 'Active', 'rejected' => 'Rejected', 'all' => 'All'] as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?php echo $statusFilter === $key ? 'active' : ''; ?>" href="approve_groups.php?status=<?php echo $key; ?>"><?php echo $label; ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead class="table-light">
        <tr><th>Group</th><th>Subject</th><th>Creator</th><th>Members</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php while ($g = $groups->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($g['name']); ?></td>
            <td><?php echo e($g['subject_name']); ?></td>
            <td><?php echo e($g['creator']); ?></td>
            <td><?php echo (int)$g['member_count']; ?>/<?php echo (int)$g['max_members']; ?></td>
            <td>
              <?php if ($g['status'] === 'active'): ?>
                <span class="badge badge-group-active">Active</span>
              <?php elseif ($g['status'] === 'pending'): ?>
                <span class="badge badge-group-pending">Pending</span>
              <?php else: ?>
                <span class="badge badge-rejected">Rejected</span>
              <?php endif; ?>
            </td>
            <td class="text-nowrap">
              <?php if ($g['status'] !== 'active'): ?>
                <a href="approve_groups.php?approve=<?php echo $g['id']; ?>" class="btn btn-sm btn-outline-success">Approve</a>
              <?php endif; ?>
              <?php if ($g['status'] !== 'rejected'): ?>
                <a href="approve_groups.php?reject=<?php echo $g['id']; ?>" class="btn btn-sm btn-outline-warning">Reject</a>
              <?php endif; ?>
              <a href="approve_groups.php?delete=<?php echo $g['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this group permanently? This removes all its members and messages too.">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
        <?php if ($groups->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-3">No study groups found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
