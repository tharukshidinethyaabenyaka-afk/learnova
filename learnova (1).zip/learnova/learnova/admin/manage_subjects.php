<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
    $name = trim($_POST['subject_name'] ?? '');
    if ($name !== '') {
        $stmt = $conn->prepare('INSERT IGNORE INTO subjects (name) VALUES (?)');
        $stmt->bind_param('s', $name);
        $stmt->execute();
    }
    header('Location: manage_subjects.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = trim($_POST['category_name'] ?? '');
    if ($name !== '') {
        $stmt = $conn->prepare('INSERT IGNORE INTO categories (name) VALUES (?)');
        $stmt->bind_param('s', $name);
        $stmt->execute();
    }
    header('Location: manage_subjects.php');
    exit;
}

if (isset($_GET['delete_subject'])) {
    $id = (int)$_GET['delete_subject'];
    $stmt = $conn->prepare('DELETE FROM subjects WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: manage_subjects.php');
    exit;
}
if (isset($_GET['delete_category'])) {
    $id = (int)$_GET['delete_category'];
    $stmt = $conn->prepare('DELETE FROM categories WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: manage_subjects.php');
    exit;
}

$subjects = $conn->query('SELECT * FROM subjects ORDER BY name');
$categories = $conn->query('SELECT * FROM categories ORDER BY name');

$BASE = '../';
$PAGE_TITLE = 'Subjects & Categories';
$ACTIVE = 'subjects';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Manage Subjects &amp; Categories</h3>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header">Subjects</div>
      <div class="card-body">
        <form method="POST" class="d-flex gap-2 mb-3">
          <input type="text" name="subject_name" class="form-control" placeholder="New subject name" required>
          <button type="submit" name="add_subject" value="1" class="btn btn-primary">Add</button>
        </form>
        <ul class="list-group">
          <?php while ($s = $subjects->fetch_assoc()): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?php echo e($s['name']); ?>
              <a href="manage_subjects.php?delete_subject=<?php echo $s['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this subject? This will remove related notes/questions/groups.">Delete</a>
            </li>
          <?php endwhile; ?>
        </ul>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card">
      <div class="card-header">Categories</div>
      <div class="card-body">
        <form method="POST" class="d-flex gap-2 mb-3">
          <input type="text" name="category_name" class="form-control" placeholder="New category name" required>
          <button type="submit" name="add_category" value="1" class="btn btn-primary">Add</button>
        </form>
        <ul class="list-group">
          <?php while ($c = $categories->fetch_assoc()): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?php echo e($c['name']); ?>
              <a href="manage_subjects.php?delete_category=<?php echo $c['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this category? This will remove related notes.">Delete</a>
            </li>
          <?php endwhile; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
