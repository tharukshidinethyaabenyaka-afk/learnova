<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

$totalUsers = $conn->query("SELECT COUNT(*) c FROM users WHERE role='student'")->fetch_assoc()['c'];
$pendingMaterials = $conn->query("SELECT COUNT(*) c FROM materials WHERE status='pending'")->fetch_assoc()['c'];
$totalMaterials = $conn->query("SELECT COUNT(*) c FROM materials")->fetch_assoc()['c'];
$pendingGroups = $conn->query("SELECT COUNT(*) c FROM study_groups WHERE status='pending'")->fetch_assoc()['c'];
$totalGroups = $conn->query("SELECT COUNT(*) c FROM study_groups WHERE status='active'")->fetch_assoc()['c'];

$recentUsers = $conn->query("SELECT * FROM users WHERE role='student' ORDER BY created_at DESC LIMIT 5");
$pendingList = $conn->query("SELECT m.*, u.name uploader FROM materials m JOIN users u ON u.id = m.uploaded_by WHERE m.status='pending' ORDER BY m.created_at DESC LIMIT 5");

$BASE = '../';
$PAGE_TITLE = 'Admin Dashboard';
$ACTIVE = 'dashboard';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Admin Dashboard</h3>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><small>Students</small><h2><?php echo (int)$totalUsers; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>Pending Notes</small><h2><?php echo (int)$pendingMaterials; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>Pending Groups</small><h2><?php echo (int)$pendingGroups; ?></h2></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><small>Active Groups</small><h2><?php echo (int)$totalGroups; ?></h2></div></div>
</div>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        Pending Note Approvals
        <a href="approve_materials.php" class="btn btn-sm btn-outline-primary">View all</a>
      </div>
      <div class="card-body">
        <?php if ($pendingList->num_rows === 0): ?>
          <p class="text-muted mb-0">Nothing pending. 🎉</p>
        <?php endif; ?>
        <?php while ($p = $pendingList->fetch_assoc()): ?>
          <div class="d-flex justify-content-between border-bottom py-2" style="border-color: var(--sm-border);">
            <div>
              <strong><?php echo e($p['title']); ?></strong><br>
              <small class="text-muted">by <?php echo e($p['uploader']); ?></small>
            </div>
            <a href="approve_materials.php" class="btn btn-sm btn-light">Review</a>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        Recently Joined Students
        <a href="manage_users.php" class="btn btn-sm btn-outline-primary">View all</a>
      </div>
      <div class="card-body">
        <?php if ($recentUsers->num_rows === 0): ?>
          <p class="text-muted mb-0">No students yet.</p>
        <?php endif; ?>
        <?php while ($u = $recentUsers->fetch_assoc()): ?>
          <div class="d-flex justify-content-between border-bottom py-2" style="border-color: var(--sm-border);">
            <div>
              <strong><?php echo e($u['name']); ?></strong><br>
              <small class="text-muted"><?php echo e($u['email']); ?></small>
            </div>
            <span class="badge bg-<?php echo $u['status'] === 'active' ? 'success' : 'danger'; ?>"><?php echo ucfirst($u['status']); ?></span>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
