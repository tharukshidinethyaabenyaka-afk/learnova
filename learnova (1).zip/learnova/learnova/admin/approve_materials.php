<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $stmt = $conn->prepare("UPDATE materials SET status = 'approved' WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Note approved.';
    header('Location: approve_materials.php');
    exit;
}

if (isset($_GET['reject'])) {
    $id = (int)$_GET['reject'];
    $stmt = $conn->prepare("UPDATE materials SET status = 'rejected' WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Note rejected.';
    header('Location: approve_materials.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare('SELECT file_path FROM materials WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row && file_exists('../' . $row['file_path'])) {
        @unlink('../' . $row['file_path']);
    }
    $stmt = $conn->prepare('DELETE FROM materials WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $_SESSION['flash_success'] = 'Note deleted.';
    header('Location: approve_materials.php');
    exit;
}

$statusFilter = $_GET['status'] ?? 'pending';
$allowed = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($statusFilter, $allowed)) { $statusFilter = 'pending'; }

$sql = "SELECT m.*, s.name subject_name, c.name category_name, u.name uploader
        FROM materials m
        JOIN subjects s ON s.id = m.subject_id
        JOIN categories c ON c.id = m.category_id
        JOIN users u ON u.id = m.uploaded_by";
if ($statusFilter !== 'all') {
    $sql .= " WHERE m.status = '" . $conn->real_escape_string($statusFilter) . "'";
}
$sql .= ' ORDER BY m.created_at DESC';
$materials = $conn->query($sql);

$BASE = '../';
$PAGE_TITLE = 'Manage Notes';
$ACTIVE = 'materials';
require '../includes/sidebar_start.php';
?>

<h3 class="mb-4">Manage Notes</h3>

<ul class="nav nav-pills mb-4">
  <?php foreach (['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'all' => 'All'] as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?php echo $statusFilter === $key ? 'active' : ''; ?>" href="approve_materials.php?status=<?php echo $key; ?>"><?php echo $label; ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead class="table-light">
        <tr><th>Title</th><th>Subject</th><th>Category</th><th>Uploader</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php while ($m = $materials->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($m['title']); ?></td>
            <td><?php echo e($m['subject_name']); ?></td>
            <td><?php echo e($m['category_name']); ?></td>
            <td><?php echo e($m['uploader']); ?></td>
            <td><span class="badge badge-<?php echo $m['status']; ?>"><?php echo ucfirst($m['status']); ?></span></td>
            <td class="text-nowrap">
              <a href="../<?php echo e($m['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Preview</a>
              <?php if ($m['status'] !== 'approved'): ?>
                <a href="approve_materials.php?approve=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-success">Approve</a>
              <?php endif; ?>
              <?php if ($m['status'] !== 'rejected'): ?>
                <a href="approve_materials.php?reject=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-warning">Reject</a>
              <?php endif; ?>
              <a href="approve_materials.php?delete=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-danger confirm-action" data-confirm="Delete this note permanently?">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
        <?php if ($materials->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-3">No notes found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '../includes/app_footer.php'; ?>
