<?php
// =====================================================
// Learnova - Authentication Helpers
// =====================================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function isStudent() {
    return isLoggedIn() && $_SESSION['role'] === 'student';
}

// Call at the top of any page that only students may view
function requireStudent() {
    if (!isStudent()) {
        header('Location: ../login.php');
        exit;
    }
}

// Call at the top of any page that only admins may view
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: ../login.php');
        exit;
    }
}

function currentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function currentUserName() {
    return $_SESSION['user_name'] ?? '';
}

function e($str) {
    // Shorthand for safely echoing output (XSS protection)
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// Two-letter initials for the sidebar avatar circle, e.g. "Kavindi Perera" -> "KP"
function userInitials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $initials = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        if ($p !== '') { $initials .= mb_strtoupper(mb_substr($p, 0, 1)); }
    }
    return $initials !== '' ? $initials : '?';
}
