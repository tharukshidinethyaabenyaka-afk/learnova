<?php
// Expects before include:
//   $BASE        = '../'
//   $PAGE_TITLE  = 'Dashboard' etc.
//   $ACTIVE      = 'dashboard' | 'groups' | 'materials' | 'questions'
//                  | 'users' | 'subjects' | 'moderation'
if (!isset($BASE)) { $BASE = '../'; }
$role = isAdmin() ? 'admin' : 'student';

$bookIcon = '<img src="' . $BASE . 'assets/img/nsbm-logo.png" alt="NSBM" class="logo-badge-img">';

$icons = [
    'home'  => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
    'book'  => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
    'users' => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    'chat'  => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    'tag'   => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41L11 22l-9-9 8.59-8.59A2 2 0 0 1 12 4h7a1 1 0 0 1 1 1v7a2 2 0 0 1-.41 1.41z"/><circle cx="16" cy="8" r="1"/></svg>',
    'flag'  => '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>',
    'logout'=> '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    'menu'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
];

if ($role === 'student') {
    $home = $BASE . 'student/dashboard.php';
    $navItems = [
        [$BASE . 'student/dashboard.php', 'Dashboard', 'home', 'dashboard'],
        [$BASE . 'student/study_groups.php', 'Study Group', 'users', 'groups'],
        [$BASE . 'student/materials.php', 'Notes', 'book', 'materials'],
        [$BASE . 'student/questions.php', 'Q&amp;A', 'chat', 'questions'],
    ];
} else {
    $home = $BASE . 'admin/dashboard.php';
    $navItems = [
        [$BASE . 'admin/dashboard.php', 'Dashboard', 'home', 'dashboard'],
        [$BASE . 'admin/manage_users.php', 'Users', 'users', 'users'],
        [$BASE . 'admin/approve_materials.php', 'Notes', 'book', 'materials'],
        [$BASE . 'admin/approve_groups.php', 'Study Groups', 'users', 'groups'],
        [$BASE . 'admin/manage_subjects.php', 'Subjects/Categories', 'tag', 'subjects'],
        [$BASE . 'admin/moderate_discussions.php', 'Moderation', 'flag', 'moderation'],
    ];
}

function renderNavLinks($items, $icons, $active) {
    $html = '';
    foreach ($items as [$href, $label, $iconKey, $key]) {
        $cls = ($key === $active) ? 'sidebar-link active' : 'sidebar-link';
        $html .= '<a class="' . $cls . '" href="' . $href . '">' . $icons[$iconKey] . '<span>' . $label . '</span></a>' . "\n";
    }
    return $html;
}
$navHtml = renderNavLinks($navItems, $icons, $ACTIVE ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($PAGE_TITLE) ? e($PAGE_TITLE) . ' - Learnova' : 'Learnova'; ?></title>
<link rel="icon" type="image/png" href="<?php echo $BASE; ?>assets/img/nsbm-logo.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/style.css">
</head>
<body>

<div class="app-shell">
  <aside class="app-sidebar">
    <a href="<?php echo $home; ?>" class="sidebar-brand text-decoration-none">
      <span class="brand-mark"><span class="logo-badge"><?php echo $bookIcon; ?></span><span class="brand-text-stack"><span class="brand-word"><span class="blue">Learn</span><span class="gold">ova</span></span><span class="brand-caption">Powered by NSBM</span></span></span>
    </a>
    <nav class="sidebar-nav">
      <?php echo $navHtml; ?>
    </nav>
    <div class="sidebar-user">
      <div class="sidebar-avatar"><?php echo e(userInitials(currentUserName())); ?></div>
      <span class="flex-grow-1 small" style="color:var(--sm-text);"><?php echo e(currentUserName()); ?></span>
    </div>
    <a href="<?php echo $BASE; ?>logout.php" class="sidebar-link mt-2"><?php echo $icons['logout']; ?><span>Logout</span></a>
  </aside>

  <div class="flex-grow-1 d-flex flex-column" style="min-width:0;">
    <div class="mobile-topbar">
      <a href="<?php echo $home; ?>" class="text-decoration-none">
        <span class="brand-mark" style="font-size:1.05rem;"><span class="logo-badge"><?php echo $bookIcon; ?></span><span class="brand-text-stack"><span class="brand-word"><span class="blue">Learn</span><span class="gold">ova</span></span><span class="brand-caption">Powered by NSBM</span></span></span>
      </a>
      <button class="btn btn-outline-secondary btn-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><?php echo $icons['menu']; ?></button>
    </div>

    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileNav" style="background:#fff;color:var(--sm-text);width:260px;">
      <div class="offcanvas-header">
        <span class="brand-mark" style="font-size:1.05rem;"><span class="logo-badge"><?php echo $bookIcon; ?></span><span class="brand-text-stack"><span class="brand-word"><span class="blue">Learn</span><span class="gold">ova</span></span><span class="brand-caption">Powered by NSBM</span></span></span>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body d-flex flex-column gap-1">
        <?php echo $navHtml; ?>
        <a href="<?php echo $BASE; ?>logout.php" class="sidebar-link mt-2"><?php echo $icons['logout']; ?><span>Logout</span></a>
      </div>
    </div>

    <main class="app-main flex-grow-1">
    <?php if (!empty($_SESSION['flash_success'])): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e($_SESSION['flash_success']); unset($_SESSION['flash_success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
    <?php if (!empty($_SESSION['flash_error'])): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
