<?php
// Expects $BASE and $PAGE_TITLE to be defined before including.
// Used only by index.php - login/register are standalone full-page layouts.
if (!isset($BASE)) { $BASE = ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($PAGE_TITLE) ? e($PAGE_TITLE) . ' - Learnova' : 'Learnova'; ?></title>
<link rel="icon" type="image/png" href="<?php echo $BASE; ?>assets/img/nsbm-logo.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg sm-navbar sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?php echo $BASE; ?>index.php">
      <span class="brand-mark" style="font-size:1.15rem;"><span class="logo-badge"><img src="<?php echo $BASE; ?>assets/img/nsbm-logo.png" alt="NSBM" class="logo-badge-img"></span><span class="brand-text-stack"><span class="brand-word"><span class="blue">Learn</span><span class="gold">ova</span></span><span class="brand-caption">Powered by NSBM</span></span></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link active" href="<?php echo $BASE; ?>index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>login.php">Login</a></li>
        <li class="nav-item"><a class="btn btn-pill-cta ms-lg-2" href="<?php echo $BASE; ?>register.php">Register</a></li>
      </ul>
    </div>
  </div>
</nav>

<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="container mt-3">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?php echo e($_SESSION['flash_success']); unset($_SESSION['flash_success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  </div>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_error'])): ?>
  <div class="container mt-3">
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?php echo e($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  </div>
<?php endif; ?>
