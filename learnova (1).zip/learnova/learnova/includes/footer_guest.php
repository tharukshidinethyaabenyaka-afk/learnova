<footer class="sm-footer text-center py-4 mt-5">
  <div class="brand-mark mb-1 justify-content-center" style="font-size:1rem;"><span class="logo-badge"><img src="<?php echo $BASE; ?>assets/img/nsbm-logo.png" alt="NSBM" class="logo-badge-img"></span><span class="brand-text-stack"><span class="brand-word"><span class="blue">Learn</span><span class="gold">ova</span></span><span class="brand-caption">Powered by NSBM</span></span></div>
  <small>Peer Learning and Academic Collaboration Platform &mdash; NSBM Green University</small><br>
  <small class="text-muted">&copy; 2026 Learnova</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $BASE; ?>assets/js/script.js"></script>
</body>
</html>
