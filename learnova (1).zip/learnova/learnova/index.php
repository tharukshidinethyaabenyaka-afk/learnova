<?php
require_once 'config/db.php';
require_once 'includes/auth.php';

if (isStudent()) { header('Location: student/dashboard.php'); exit; }
if (isAdmin())   { header('Location: admin/dashboard.php'); exit; }

$BASE = '';
$PAGE_TITLE = 'Home';
require 'includes/header_guest.php';

$stats = ['materials' => 0, 'questions' => 0, 'groups' => 0, 'students' => 0];
$r = $conn->query("SELECT COUNT(*) c FROM materials WHERE status='approved'");
$stats['materials'] = $r->fetch_assoc()['c'];
$r = $conn->query("SELECT COUNT(*) c FROM questions WHERE status='visible'");
$stats['questions'] = $r->fetch_assoc()['c'];
$r = $conn->query("SELECT COUNT(*) c FROM study_groups WHERE status='active'");
$stats['groups'] = $r->fetch_assoc()['c'];
$r = $conn->query("SELECT COUNT(*) c FROM users WHERE role='student'");
$stats['students'] = $r->fetch_assoc()['c'];
?>

<div class="hero-full hero-root">
  <video class="hero-video-bg" autoplay muted loop playsinline poster="assets/img/campus-watercolor.png">
    <source src="assets/video/hero.mp4" type="video/mp4">
  </video>
  <div class="hero-overlay"></div>
  <div class="grain-layer"></div>
  <div class="hero-inner">
    <h1 class="hero-title">Peer Learning, <em>Built</em><br><span class="hero-title-accent">For How You <em>Actually</em> Study.</span></h1>
    <p class="hero-tagline">Share notes, ask questions, and study together with fellow NSBM students.</p>
    <a href="register.php" class="btn btn-primary btn-lg">Get Started <span class="btn-arrow">&rarr;</span></a>
  </div>
</div>

<div class="container py-4">
  <h2 class="text-center mb-4" style="font-size:1.7rem;">Everything you need to study smarter</h2>
  <div class="row g-3 mb-5">
    <div class="col-md-4"><div class="feature-card h-100">
      <h3>📄 Notes</h3>
      <p>Upload lecture notes and resources, and download materials shared by peers.</p>
    </div></div>
    <div class="col-md-4"><div class="feature-card h-100">
      <h3>❓ Q&amp;A</h3>
      <p>Post academic questions and help fellow students by answering theirs.</p>
    </div></div>
    <div class="col-md-4"><div class="feature-card h-100">
      <h3>👥 Study Group</h3>
      <p>Create or join subject-based study groups, chat, and collaborate with peers.</p>
    </div></div>
  </div>

  <div class="row g-3 mb-5">
    <div class="col-6 col-md-3"><div class="stat-card"><small>Approved Notes</small><h2><?php echo (int)$stats['materials']; ?></h2></div></div>
    <div class="col-6 col-md-3"><div class="stat-card"><small>Questions Asked</small><h2><?php echo (int)$stats['questions']; ?></h2></div></div>
    <div class="col-6 col-md-3"><div class="stat-card"><small>Study Groups</small><h2><?php echo (int)$stats['groups']; ?></h2></div></div>
    <div class="col-6 col-md-3"><div class="stat-card"><small>Students Joined</small><h2><?php echo (int)$stats['students']; ?></h2></div></div>
  </div>
</div>

<?php require 'includes/footer_guest.php'; ?>
